

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <div class="card-block">
                    <h6 class="card-title text-bold">All Customers</h6>
                    <?php if(session('item-created')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('item-created')); ?>

                        </div>
                    <?php elseif(session('item-updated')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('item-updated')); ?>

                        </div>
                    <?php elseif(session('measurment-date-updated')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('measurment-date-updated')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="all-items-datatable" class="table table-striped table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>Item Code</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Type</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->item_code); ?></td>
                                        <td><?php echo e($item->item_desc); ?></td>
                                        <td><?php echo e($item->item_price); ?></td>
                                        <td><?php echo e($item->function_type->name); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('item.edit', $item->id)); ?>">
                                                <button type="button" class="btn btn-success btn-sm">Edit</button>
                                            </a>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#itemDeleteModal<?php echo e($item->id); ?>">
                                                Delete
                                            </button>
                                        </td>
                                        <div class="modal fade" id="itemDeleteModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="itemDeleteModal<?php echo e($item->id); ?>Label" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="itemDeleteModal<?php echo e($item->id); ?>Label">Modal title</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('item.destroy', $item->id)); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            Are you sure you want to delete this item?
                                                    </div>
                                                    <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                                                            <button type="submit" class="btn btn-danger">Yes</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </tr>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Item Code</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Type</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_dataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\photographer_information_system\resources\views/admin/all-items.blade.php ENDPATH**/ ?>