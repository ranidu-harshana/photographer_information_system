

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <div class="card-block">
                    <h6 class="card-title text-bold">All Customers</h6>
                    <?php if(session('item-created')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('item-created')); ?>

                        </div>
                    <?php elseif(session('item-updated')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('item-updated')); ?>

                        </div>
                    <?php elseif(session('measurment-date-updated')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('measurment-date-updated')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="all-customers-datatable" class="table table-striped table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>Bill No</th>
                                    <th>Name</th>
                                    <th>Function Type</th>
                                    <th>Branch</th>
                                    <th>View</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($customer->bill_nulber); ?></td>
                                        <td><?php echo e($customer->name); ?></td>
                                        <td><?php echo e($customer->function_type->name); ?></td>
                                        <td>branch</td>
                                        <td>
                                            <a href="<?php echo e(route('customer.show', $customer->id)); ?>" class="btn btn-primary btn-sm">View</a>
                                        </td>
                                    </tr>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Bill No</th>
                                    <th>Name</th>
                                    <th>Function Type</th>
                                    <th>Branch</th>
                                    <th>View</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_dataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\photographer_information_system\resources\views/admin/all-customers.blade.php ENDPATH**/ ?>