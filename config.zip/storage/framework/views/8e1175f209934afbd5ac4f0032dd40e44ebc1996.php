

<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-md-7">
            <div class="card-box">
                <h4 class="card-title">Edit Item</h4>

                <?php if(session('failed')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('failed')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('item.update', $item->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="form-group">
                        <label>Item Code</label>
                        <input name="item_code" value="<?php echo e($item->item_code); ?>" type="text" required class="form-control <?php $__errorArgs = ['item_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off">
                        <?php $__errorArgs = ['item_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Item Description</label>
                        <input name="item_desc" value="<?php echo e($item->item_desc); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Item Type</label>
                        <select name="function_type_id" id="" class="form-control">
                            <option value="<?php echo e($item->function_type_id); ?>"><?php echo e($item->function_type->name); ?></option>
                            <?php $__currentLoopData = $function_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $function_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($function_type->name != $item->function_type->name): ?>
                                    <option value="<?php echo e($function_type->id); ?>"><?php echo e($function_type->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Item Price</label>
                        <input name="item_price" id="item_price" value="<?php echo e($item->item_price); ?>" type="number" class="form-control" autocomplete="off">
                    </div>


                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\photographer_information_system\resources\views/admin/edit-item.blade.php ENDPATH**/ ?>