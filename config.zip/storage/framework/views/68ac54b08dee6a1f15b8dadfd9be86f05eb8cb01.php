

<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-md-7">
            <div class="card-box">
                <h4 class="card-title">Create Package</h4>

                <?php if(session('failed')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('failed')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('package.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <label>Package Code</label>
                        <input name="package_code" value="<?php echo e(old('package_code')); ?>" type="text" required class="form-control <?php $__errorArgs = ['package_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off">
                        <?php $__errorArgs = ['package_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Package Name</label>
                        <input name="name" value="<?php echo e(old('name')); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Package Description</label>
                        <input name="desc" value="<?php echo e(old('desc')); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Function Type</label>
                        <select name="function_type_id" id="function_type_id" class="form-control">
                            <?php $__currentLoopData = $function_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $function_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($function_type->id); ?>"><?php echo e($function_type->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Package Price</label>
                        <input name="package_price" id="package_price" value="<?php echo e(old('package_price')); ?>" type="number" class="form-control" autocomplete="off">
                    </div>


                    <div class="form-group">
                        <label for="item" class="col-form-label text-md-end"><?php echo e(__('Item Name')); ?></label>
    
                        <div class="form-control mt-2 border border-success" id="display_area" style="height: 192px; overflow: auto">
                            No Items
                        </div>
                    </div>
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
    <script>
        $(document).ready(function(){
            var function_type_id = $('#function_type_id').val();
            $.ajax({
                url: "../get/item/"+function_type_id,
                type: "GET",
                success: function(data){
                    html = '';
                    if(data.length != 0) {
                        data.forEach(element => {
                            html += '<div class="form-check">';
                            html += '<input class="form-check-input" type="checkbox" value="'+ element.id +'" name="items[]" id="items'+ element.id +'">';
                            html += '<label class="form-check-label" for="items'+ element.id +'">';
                            html += element.item_desc;
                            html += '</label></div>';
                        });
                    }else{
                        html = 'No Items';
                    }
                    $("#display_area").html(html);
                }
            })
            $("#function_type_id").change(function(){
                var function_type_id = $('#function_type_id').val();
                $.ajax({
                    url: "../get/item/"+function_type_id,
                    type: "GET",
                    success: function(data){
                        html = '';
                        if(data.length != 0) {
                            data.forEach(element => {
                                html += '<div class="form-check">';
                                html += '<input class="form-check-input" type="checkbox" value="'+ element.id +'" name="items[]" id="items'+ element.id +'">';
                                html += '<label class="form-check-label" for="items'+ element.id +'">';
                                html += element.item_desc;
                                html += '</label></div>';
                            });
                        }else{
                            html = 'No Items';
                        }
                        $("#display_area").html(html);
                    }
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\photographer_information_system\resources\views/admin/create-package.blade.php ENDPATH**/ ?>