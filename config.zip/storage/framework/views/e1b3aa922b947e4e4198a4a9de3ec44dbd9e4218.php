

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-7">
            <div class="card-box">
                <h4 class="card-title">Schedule</h4>

                <?php if(session('failed')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('failed')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('customer.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <label>Bill Number</label>
                        <input name="bill_nulber" value="<?php echo e(old('bill_nulber')); ?>" type="text" required class="form-control <?php $__errorArgs = ['bill_nulber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off">
                        <?php $__errorArgs = ['bill_nulber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    

                    <div class="form-group">
                        <label>Name</label>
                        <input name="name" value="<?php echo e(old('name')); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Address</label>
                        <input name="address" value="<?php echo e(old('address')); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>
                    
                    <div class="form-group">
                        <label>Mobile No. 1</label>
                        <input name="mob_no1" value="<?php echo e(old('mob_no1')); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>
                    
                    <div class="form-group">
                        <label>Mobile No. 2</label>
                        <input name="mob_no2" value="<?php echo e(old('mob_no2')); ?>" type="text" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Type </label>
                        <select name="function_type_id" id="function_type_id" required class="form-control" value="<?php echo e(old('type')); ?>">
                            <option value="">Select Type</option>
                            <option value="1">Wedding</option>
                            <option value="2">Photoshoot</option>
                            <option value="3">Event</option>
                        </select>
                    </div>

                    
                    <div id="wedding_type">
                        <div class="form-group">
                            <label>Wedding Type </label>
                            <select name="wedding_type_id" id="wedding_type_id" class="form-control" value="<?php echo e(old('type')); ?>">
                                <option value="">Select Type</option>
                                <option value="1">Wedding Only</option>
                                <option value="2">Homecomming Only</option>
                                <option value="3">Wedding & Hommcomming</option>
                            </select>
                        </div>
                    </div>
                    

                    
                    <div id="wedding_div">
                        <div class="form-group">
                            <label>Wedding Date</label>
                            <input name="wedding_date" id="wedding_date" value="<?php echo e(old('wedding_date')); ?>" type="date" class="form-control <?php $__errorArgs = ['wedding_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off" min="<?php echo e(date('Y-m-d')); ?>">
                            <?php $__errorArgs = ['wedding_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label>Wedding Location</label>
                            <input name="wedding_location" id="wedding_location" value="<?php echo e(old('wedding_location')); ?>" type="text" class="form-control" autocomplete="off">
                        </div>
                    </div>
                    

                    
                    <div id="homecomming_div">
                        <div class="form-group">
                            <label>Homecomming Date</label>
                            <input name="home_com_date" id="home_com_date" value="<?php echo e(old('home_com_date')); ?>" type="date" class="form-control <?php $__errorArgs = ['home_com_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off" min="<?php echo e(date('Y-m-d')); ?>">
                            <?php $__errorArgs = ['home_com_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label>Homecomming Location</label>
                            <input name="home_com_location" id="home_com_location" value="<?php echo e(old('home_com_location')); ?>" type="text" class="form-control" autocomplete="off">
                        </div>
                    </div> 
                    

                    
                    <div id="event_div">
                        <div class="form-group">
                            <label>Event Date</label>
                            <input name="event_date" id="event_date" value="<?php echo e(old('event_date')); ?>" type="date" class="form-control <?php $__errorArgs = ['event_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off" min="<?php echo e(date('Y-m-d')); ?>">
                            <?php $__errorArgs = ['event_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label>Event Location</label>
                            <input name="event_location" id="event_location" value="<?php echo e(old('event_location')); ?>" type="text" class="form-control" autocomplete="off">
                        </div>
                    </div>
                    

                    
                    <div id="photosshoot_div">
                        <div class="form-group">
                            <label>Photoshoot Date</label>
                            <input name="photo_shoot_date" id="photo_shoot_date" value="<?php echo e(old('photo_shoot_date')); ?>" type="date" class="form-control <?php $__errorArgs = ['photo_shoot_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off" min="<?php echo e(date('Y-m-d')); ?>">
                            <?php $__errorArgs = ['photo_shoot_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label>Photoshoot Location</label>
                            <input name="photo_shoot_location" id="photo_shoot_location" value="<?php echo e(old('photo_shoot_location')); ?>" type="text" class="form-control" autocomplete="off">
                        </div>
                    </div>
                    

                    <div class="form-group">
                        <label>Total Amount</label>
                        <input name="total_payment" id="total_payment" value="<?php echo e(old('total_payment')); ?>" type="text" class="form-control" autocomplete="off">
                    </div>
                    <label>Discount</label><br>
                    <div class="input-group mb-3">
                        
                        <div class="input-group-prepend">
                            <select name="" id="discount_by" class="form-control">
                                <option value="">Select</option>
                                <option value="1">By Amount</option>
                                <option value="2">By Percentage</option>
                            </select>
                        </div>
                        <input type="text" name="" id="discount_by_field" class="form-control" aria-label="Text input with dropdown button">
                        <input type="hidden" name="discount" id="discount">
                    </div>

                    <div class="form-group">
                        <label>Advance Payment</label>
                        <input name="advance_payment" id="advance_payment" value="<?php echo e(old('advance_payment')); ?>" type="text" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Balance to be paid</label>
                        <input name="balance_to_be_paid" id="balance_to_be_paid" type="number" class="form-control" disabled>
                    </div>

                    <div class="text-right">
                        <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
        
    </div>


    


    <script>
        $(document).ready(function(){
            $("#submit").on('click',function(){
                $.ajaxSetup({
                    headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "../set_tab0_session",
                    type: "POST",
                })
            });

            $('#discount_by_field').prop("disabled", true);
            $('#wedding_type').hide();
            $('#wedding_div').hide();
            $('#homecomming_div').hide();
            $('#event_div').hide();
            $('#photosshoot_div').hide();
            $('#photo_shoot_date').prop('required', false)
            $('#home_com_date').prop('required', false)
            $('#wedding_date').prop('required', false)
            $('#event_date').prop('required', false)
            $('#wedding_type_id').prop('required', false)
            $('#function_type_id').change(function() {
                var function_type_id = $('#function_type_id').val()
                if(function_type_id == 2){
                    $('#wedding_type').hide();
                    $('#wedding_div').hide();
                    $('#homecomming_div').hide();
                    $('#event_div').hide();
                    $('#photosshoot_div').show();
                    $('#photo_shoot_date').prop('required', true)
                    $('#home_com_date').prop('required', false)
                    $('#wedding_date').prop('required', false)
                    $('#event_date').prop('required', false)
                    $('#wedding_type_id').prop('required', false)
                }else if (function_type_id == 1) {
                    $('#wedding_type').show();
                    $('#wedding_div').hide();
                    $('#homecomming_div').hide();
                    $('#event_div').hide();
                    $('#photosshoot_div').hide();
                    $('#wedding_type_id').prop('required', true)
                    $('#wedding_type_id').change(function() {
                        var wedding_type_id = $('#wedding_type_id').val();
                        if(wedding_type_id == 1) {
                            $('#wedding_type').show();
                            $('#wedding_div').show();
                            $('#homecomming_div').hide();
                            $('#event_div').hide();
                            $('#photosshoot_div').hide();
                            $('#photo_shoot_date').prop('required', false)
                            $('#home_com_date').prop('required', false)
                            $('#wedding_date').prop('required', true)
                            $('#event_date').prop('required', false)
                            $('#wedding_type_id').prop('required', false)
                        }else if(wedding_type_id == 2) {
                            $('#wedding_type').show();
                            $('#wedding_div').hide();
                            $('#homecomming_div').show();
                            $('#event_div').hide();
                            $('#photosshoot_div').hide();
                            $('#photo_shoot_date').prop('required', false)
                            $('#home_com_date').prop('required', true)
                            $('#wedding_date').prop('required', false)
                            $('#event_date').prop('required', false)
                            $('#wedding_type_id').prop('required', false)
                        }else if(wedding_type_id == 3) {
                            $('#wedding_type').show();
                            $('#wedding_div').show();
                            $('#homecomming_div').show();
                            $('#event_div').hide();
                            $('#photosshoot_div').hide();
                            $('#photo_shoot_date').prop('required', false)
                            $('#home_com_date').prop('required', true)
                            $('#wedding_date').prop('required', true)
                            $('#event_date').prop('required', false)
                            $('#wedding_type_id').prop('required', false)
                        }else{
                            $('#wedding_type').hide();
                            $('#wedding_div').hide();
                            $('#homecomming_div').hide();
                            $('#event_div').hide();
                            $('#photosshoot_div').hide();
                            $('#photo_shoot_date').prop('required', false)
                            $('#home_com_date').prop('required', false)
                            $('#wedding_date').prop('required', false)
                            $('#event_date').prop('required', false)
                            $('#wedding_type_id').prop('required', false)
                        }
                    });
                }else if(function_type_id == 3){
                    $('#wedding_type').hide();
                    $('#wedding_div').hide();
                    $('#homecomming_div').hide();
                    $('#event_div').show();
                    $('#photosshoot_div').hide();
                    $('#photo_shoot_date').prop('required', false)
                    $('#home_com_date').prop('required', false)
                    $('#wedding_date').prop('required', false)
                    $('#event_date').prop('required', true)
                    $('#wedding_type_id').prop('required', false)
                }else{
                    $('#wedding_type').hide();
                    $('#wedding_div').hide();
                    $('#homecomming_div').hide();
                    $('#event_div').hide();
                    $('#photosshoot_div').hide();
                    $('#photo_shoot_date').prop('required', false)
                    $('#home_com_date').prop('required', false)
                    $('#wedding_date').prop('required', false)
                    $('#event_date').prop('required', false)
                    $('#wedding_type_id').prop('required', false)
                }
            });
        });

        $("#discount_by").change(function(){
            if($("#discount_by").val() == 1){
                $('#discount_by_field').prop("disabled", false);
                $('#discount_by_field').val(null);
                $('#discount').val(null);
            }
            else if($("#discount_by").val() == 2){
                $('#discount_by_field').prop("disabled", false);
                $('#discount_by_field').val(null);
                $('#discount').val(null);
            }else{
                $('#discount_by_field').prop("disabled", true);
                $('#discount_by_field').val(null);
                $('#discount').val(null);
            }
        });
        $('#total_payment').keyup(function(){
            var total_payment = $('#total_payment').val()
            var discount = $('#discount').val()
            var advance_payment = $('#advance_payment').val()
            
            var balance_to_be_paid = Number(total_payment)-(Number(discount)+Number(advance_payment));
            $('#balance_to_be_paid').val(balance_to_be_paid);
        });

        $('#discount_by_field').keyup(function(){
            $('#discount').val($('#discount_by_field').val());
            var total_payment = $('#total_payment').val()
            var discount = $('#discount').val()
            var advance_payment = $('#advance_payment').val()
            var discount_by = $('#discount_by').val()
            if(discount_by == 1) {
                var balance_to_be_paid = Number(total_payment)-(Number(discount)+Number(advance_payment));
            }else if(discount_by == 2){
                var balance_to_be_paid = Number(total_payment)-(Number(total_payment)*(Number(discount)/100)+Number(advance_payment));
            }
            
            $('#balance_to_be_paid').val(balance_to_be_paid);
        });

        $('#advance_payment').keyup(function(){
            var total_payment = $('#total_payment').val()
            var discount = $('#discount').val()
            var advance_payment = $('#advance_payment').val()

            var balance_to_be_paid = Number(total_payment)-(Number(discount)+Number(advance_payment));
            $('#balance_to_be_paid').val(balance_to_be_paid);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\photographer_information_system\resources\views/admin/create-customer.blade.php ENDPATH**/ ?>