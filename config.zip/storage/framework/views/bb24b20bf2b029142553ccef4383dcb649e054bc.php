

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <div class="card-block">
                    <h6 class="card-title text-bold">All Packages</h6>
                    <?php if(session('package-created')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('package-created')); ?>

                        </div>
                    <?php elseif(session('package-updated')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('package-updated')); ?>

                        </div>
                    <?php elseif(session('measurment-date-updated')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('measurment-date-updated')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="all-packages-datatable" class="table table-striped table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>Package Code</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Type</th>
                                    <th>Action</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($package->package_code); ?></td>
                                        <td><?php echo e($package->name); ?></td>
                                        <td><?php echo e($package->desc); ?></td>
                                        <td><?php echo e($package->package_price); ?></td>
                                        <td><?php echo e($package->function_type->name); ?></td>
                                        <td>
                                            <div class="btn-group btn-group-sm" role="group" data-toggle="tooltip" data-trigger="hover" data-placement="top" title="View Items">
                                                <button type="button" class="btn btn-warning btn-sm" name="view" id="view" data-toggle="modal" data-target="#viewPackageItemsModal<?php echo e($package->id); ?>"><i class="far fa-eye"></i> </button>
                                                <div class="modal fade" id="viewPackageItemsModal<?php echo e($package->id); ?>" tabindex="-1" role="dialog" aria-labelledby="viewPackageItemsModal<?php echo e($package->id); ?>Label" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="viewPackageItemsModal<?php echo e($package->id); ?>Label">All Items - <span class="badge badge-success"><?php echo e($package->package_code); ?></span></h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <?php $__currentLoopData = $package->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <input type="checkbox" checked disabled name="" id=""> <?php echo e($item->item_desc); ?> <br>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                            <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="btn-group" role="group" aria-label="attach" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" title="Attach Items">
                                                <form action="<?php echo e(route('item.attach', $package->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="button" class="btn btn-success btn-sm" onclick="openModal(<?php echo e($package->id); ?>)" >
                                                        <i class="fas fa-paperclip"></i>
                                                    </button>
                                                    <div class="modal fade" id="attachPackageModal<?php echo e($package->id); ?>" tabindex="-1" role="dialog" aria-labelledby="attachPackageModal<?php echo e($package->id); ?>Label" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="attachPackageModal<?php echo e($package->id); ?>Label">Attach Items - <span class="badge badge-success"><?php echo e($package->package_code); ?></span> </h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body" id="attachPackageModalBody<?php echo e($package->id); ?>">
                                                                    
                                                                </div>
                                                                <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                                        <button type="submit" class="btn btn-success">Done</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="btn-group btn-group-sm" role="group" aria-label="detach" data-toggle="tooltip" data-trigger="hover" data-placement="top" title="Detach Items">
                                                <form action="<?php echo e(route('item.detach', $package->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field("DELETE"); ?>
                                                    <button type="button" class="btn btn-danger btn-sm" name="mark_as_done" data-toggle="modal" data-target="#detachItemsModal<?php echo e($package->id); ?>"><i class="fas fa-unlink"></i></button>
                                                    <div class="modal fade" id="detachItemsModal<?php echo e($package->id); ?>" tabindex="-1" role="dialog" aria-labelledby="detachItemsModal<?php echo e($package->id); ?>Label" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="detachItemsModal<?php echo e($package->id); ?>Label">Dettach Items - <span class="badge badge-success"><?php echo e($package->package_code); ?></span></h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <?php $__currentLoopData = $package->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <input type="checkbox" id="detach_items<?php echo e($package->id); ?><?php echo e($item->id); ?>" name="detach_items[]" value="<?php echo e($item->id); ?>"> <label for="detach_items<?php echo e($package->id); ?><?php echo e($item->id); ?>"> <?php echo e($item->item_desc); ?></label>  <br>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-danger">Done</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('package.edit', $package->id)); ?>">
                                                <button type="button" class="btn btn-success btn-sm">Edit</button>
                                            </a>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#packageDeleteModal<?php echo e($package->id); ?>">
                                                Delete
                                            </button>
                                        </td>
                                        <div class="modal fade" id="packageDeleteModal<?php echo e($package->id); ?>" tabindex="-1" role="dialog" aria-labelledby="packageDeleteModal<?php echo e($package->id); ?>Label" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="packageDeleteModal<?php echo e($package->id); ?>Label">Modal title</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('package.destroy', $package->id)); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            Are you sure you want to delete this package?
                                                    </div>
                                                    <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                                                            <button type="submit" class="btn btn-danger">Yes</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </tr>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Package Code</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Type</th>
                                    <th>Action</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function openModal(package_id) {
            $('#attachPackageModal'+package_id).modal('show');
            

            $.ajax({
				url: "../get_package_items/"+package_id,
				type: "GET",
				success: function(data){
                    html = '';
                    if (data.length != 0) {
                        data.forEach(element => {
                            html += '<input type="checkbox" id="attach_items'+package_id+''+element.id+'" name="attach_items[]" value="'+element.id+'"> <label for="attach_items'+package_id+''+element.id+'">'+element.item_desc+'</label> <br>';
                        });
                    }else{
                        html = '<div class="alert alert-success" role="alert">No any Items for this Package</div>';
                    }
					
                    $("#attachPackageModalBody"+package_id).html(html);
				}
			})
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_dataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\photographer_information_system\resources\views/admin/all-packages.blade.php ENDPATH**/ ?>