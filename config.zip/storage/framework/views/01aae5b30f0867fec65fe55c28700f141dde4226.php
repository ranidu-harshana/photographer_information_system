

<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-md-7">
            <div class="card-box">
                <h4 class="card-title">Edit Package</h4>

                <?php if(session('failed')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('failed')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('package.update', $package->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="form-group">
                        <label>Package Code</label>
                        <input name="package_code" disabled value="<?php echo e($package->package_code); ?>" type="text" required class="form-control <?php $__errorArgs = ['package_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off">
                        <?php $__errorArgs = ['package_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Package Name</label>
                        <input name="name" value="<?php echo e($package->name); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Package Description</label>
                        <input name="desc" value="<?php echo e($package->desc); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Package Price</label>
                        <input name="package_price" id="package_price" value="<?php echo e($package->package_price); ?>" type="number" class="form-control" autocomplete="off">
                    </div>


                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\photographer_information_system\resources\views/admin/edit-package.blade.php ENDPATH**/ ?>